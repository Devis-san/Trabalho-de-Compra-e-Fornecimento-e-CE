﻿using System;
using System.Collections.Generic;

namespace TrabalhoCE
{
    class Programa
    {
        public static void Main(string[] args)
        {
            bool Menu = true;
            while (Menu)
            {
                Menu = MenuP();
            }
        }
        private static bool MenuP()
        {
            var key == Console.ReadLine;

            Console.Clear();
            Console.WriteLine("Digite '1' para acessar o exercício [1] e [2].");
            Console.WriteLine("Digite '2' para acessar o exercício [3].");
            Console.WriteLine("Digite '3' para acessar o exercício [4].");
            Console.WriteLine("Digite '4' para acessar o exercício [5].");
            Console.WriteLine("Digite '5' para acessar o exercício [6].");
            Console.WriteLine("Digite '6' para fechar o programa.");

            if (key == "1")
            {
                Console.Clear();
                fornecer fornecer_ = new fornecer("Hugo Bento", "12.345.678/0001-01");
                product productf = new productf("Whindowson 10", 99.99, 10.00, fornecer_);
                productf.Imprimir();
                Console.WriteLine("Pressione qualquer tecla pra sair");
                Console.ReadKey();
            }
            else
            {
                return true;
            }

            if (key == "2")
            {
                Console.Clear();
                license pufe = new license("Puffe", 1999.90, "LTRJ-PO0P-SEGR-9YTE");
                estoque estoque_ = new estoque();

                for(int x = 0; x < 10; x++)
                {
                    estoque_.add(pufe);
                }

                for(int x = 0; x < 2; x++)
                {
                    estoque_.remove(pufe)
                }

                estoque_.imprimestoque();
                Console.WriteLine("Pressione qualquer tecla pra sair")
                Console.ReadKey();

            }
            else
            {
                return true;
            }

            if (key == "3")
            {
                Console.Clear();
                license pufe2 = new license("Pufe", 1999.90, "LTRJ-PO0P-SEGR-9YTE");
                license PS4 = new license("PS4", 2999.90, "TTR9-PODE-LITT-4ARO");

                carinho carrinho_ = new carrinho();
                estoque estoque_2 = new estoque();

                for(int x = 0; x < 10; int++)
                {
                    carrinho_.add(pufe2);
                }
                for(int x = 0; x < 2; x++)
                {
                    carrinho_.add(PS4);
                }

                for(int x = 0; x < 10; x++)
                {
                    estoque_2.add(pufe2);
                    estoque_2.add(PS4);
                }

                client client_ = new client(nome: "Jhuan Robert", cpf: "658.784.925-25");
                compras compras_ = new compras(carrinho_: carrinho_, estoque_: estoque_2, cliente_: client_);
                compras.comprar_product();
                compras.imprimirecibo();
                Console.WriteLine("Pressione qualquer tecla para sair");
                Console.ReadKey();
            }
            else
            {
                return true;
            }

            if (key == "4")
            {
                Console.Clear();
                fornecer fornecer_2 = new fornecer("Fornecedor 2", "12.345.678/0001-01");
                fornecer fornecer_3 = new fornecer("Fornecedor 3", "90.766.546/0001-90");
                relatorio relatorfornecer_ = new relatorio(titulo: "Compras", descricao: "Fornecedores");

                relatorfornecer_.additem(fornecer_2);
                relatorfornecer_.additem(fornecer_3);
                relatorfornecer_.imprimirelator();

                license sistema_1 = new license("Sistema 1", 899.99, "LFTD-PW0D-TU2A-MM4N");
                license sistema_2 = new license("Sistema 2", 699.99, "PODE-7TRW-LMOO-Y8UO");
                relatorio relatorlicense = relatorio(titulo: "Relatorio", descricao: "Compras");

                relatorlicense.additem(sistema_1);
                relatorlicense.additem(sistema_2);
                relatorlicense.imprimirelator();
                Console.WriteLine("Pressione qualquer tecla para sair");
                Console.ReadKey();
            }
            else
            {
                return true;
            }

            if (key == "5")
            {
                Console.Clear();
                license paulinux = new license("Tux Paulinux", 499.90, "W9TO-P87U-2QER-YT6R");
                ass pimpolho00 = new ass("Paulinux Pimpolho00", 29.90, 15, "OUY7-P9OI-OIJJ-FDT3");

                ass corehul = new ass("Adolfo Corehul", mensalidade: 79.90, 15, "LLLA-OJUD-GFRF-34FE");
                ass cottonshopi = new ass("Adolfo Cottonshopi", mensalidade: 79.90, 15, "LLLA-OJUD-GFRF-34FE");
                ass premillere = new ass("Adolfo Premillere", mensalidade: 89.90, 12, "RLBD-YTRZ-UPH7-VQGM");
                fornecer fornecer_4 = new fornecer(nome: "Rodolfo Pipocas", cnpj: "54.655.987/0001-08");

                productf mausi = new productf("Mausi Paulinux", 109.99, 55.99, fornecer_4);
                productf lepetop = new productf("Lepetop Doul", 5599.99, 132.55, fornecer_4);

                carrinho carrinho_ = new carrinho();

                carrinho_.add(paulinux);
                carrinho_.add(pimpolho00, 3);
                carrinho_.add(corehul);
                carrinho_.add(cottonshopi);
                carrinho_.add(premillere);
                carrinho_.add(mausi, 3);
                carrinho_.add(lepetop);

                carrinho_.imprimircarrinho();

                relator relatorarte = new relatorio("Relatorio de Artes", "Esse relatorio apresenta os sistemas disponiveis na loja.");

                relatorarte.additem(cottonshopi);
                relatorarte.additem(premillere);
                relatorarte.additem(corehul);
                relatorarte.imprimirelator();

                client Hermino = new client("Hermino Falabela", "123.456.789-10");
                client Hammud = new client("Hammud Hamun", "109.876.543-21");

                relatorio relatorclient = new relatorio("Relatorio de Cliente", "Relatorio da lista de clientes desse mês.");
                relatorclient.additem(Hermino);
                relatorclient.additem(Hammud);
                relatorclient.imprimirelator();
                Console.WriteLine("Pressione qualquer tecla para sair");
                Console.ReadKey();
            }
            else
            {
                return true;
            }
            if (key == "6")
            {
                return false;
            }

        }
    }
}
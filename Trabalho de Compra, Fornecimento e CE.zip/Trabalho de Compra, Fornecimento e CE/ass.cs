﻿using System;
using System.Diagnostics.Tracing;

namespace TarefaCE
{
    public class ass : license
    {
        private int duration_;

        public double duration
        {
            get
            {
                return this.duration_;
            }
        }

        public ass(string nome, double mensalidade, int duracao, string chave) : base(nome, mensalidade, chave)
        {
            this.duration_ = duracao;
        }

        public override double CalValTal()
        {
            return this.preco_ * this.duration_;
        }

        public override void Imprimir()
        {
            Console.WriteLine("Sistema:\t{0}", this.nome);
            Console.WriteLine("Mensalidade:\t$ {0:0.00}", this.preco_);
            Console.WriteLine("Duração:\t{0}", this.duration_);
            Console.WriteLine("Valor:\t\t$ {0:0.00}", this.CalValTal());
        }
    }
}
﻿using System;
using System.Linq;
using System.Collections.Generic;
using TarefaCE;

namespace TarefaCE
{
    public class carrinho
    {
        private Dictionary<product, int> itens_;

        public Dictionary<product, int> itens
        {
            get
            {
                return this.itens_;
            }
        }

        public double total
        {
            get
            {
                double soma = 0;
                foreach (KeyValuePair<product, int> ordenado in this.itens_)
                    soma += ordenado.Key.CalValTal() * ordenado.Value;

                return soma;
            }
        }

        public carrinho()
        {
            this.itens_ = new Dictionary<product, int>();
        }

        public void add(procuct item, int quantia)
        {
            if (this.itens_.ContainsKey(item))
                this.itens_[item] = this.itens_[item] + quantia;
            else
                this.itens_[item] = quantia;
        }

        public void add(product item)
        {
            this.add(item, 1);
        }

        public void add(List<product> itens)
        {
            foreach (var item in itens)
            {
                this.add(item);
            }
        }

        public void add(Dictionary<product, int> itens)
        {
            foreach (KeyValuePair<product, int> ordenado in itens)
            {
                this.add(ordenado.Key, ordenado.Value);
            }
        }

        public void limpo()
        {
            itens_.Clear();
        }

        public void imprimircarro()
        {
            foreach (KeyValuePair<product, int> ordenado in this.itens_)
            {
                ordenado.Key.imprimir();
                Console.WriteLine("Quantidade:\t{0}", ordenado.Value);
                Console.WriteLine("Subtotal:\t${0:0.00}", ordenado.Value * ordenado.Key.CalValTal());
            }
            Console.WriteLine("Valor Total no Carrinho:\t$ {0:0.00}", this.total);
        }
    }
}
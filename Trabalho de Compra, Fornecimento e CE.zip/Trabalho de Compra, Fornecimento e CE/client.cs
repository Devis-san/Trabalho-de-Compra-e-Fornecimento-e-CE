﻿using System;
using TarefaCE;

namespace TarefaCE
{
    public class client : imprimido
    {
        private string nome_;
        private string cpf_;

        public string Nome
        {
            get
            {
                return this.nome_;
            }
        }

        public int CPF
        {
            get
            {
                return this.cpf_;
            }
        }

        public client(string nome, string cpf)
        {
            this.nome_ = nome;
            this.cpf_ = cpf;
        }
        public void imprimir()
        {
            Console.WriteLine("Nome:\t{0}", this.Nome);
            Console.WriteLine("CPF:\t{0}", this.CPF);
        }
    }
}
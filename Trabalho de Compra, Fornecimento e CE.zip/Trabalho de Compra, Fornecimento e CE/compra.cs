﻿using System;
using System.Linq;
using System.Collections.Generic;
using TarefaCE;

namespace TarefaCE
{
    public class compras
    {
        private compraatrib compraatrib_;
        private carrinho carrinho_;
        private estoque estoque_;

        public compras(carrinho ccarrinho, estoque eestoque, cliente ccliente)
        {
            this.compraatrib_ = new compraatrib(ccliente);
            this.carrinho_ = ccarrinho;
            this.estoque_ = eestoque;
        }

        public bool confestoque()
        {
            foreach(var item in carrinho_.itens)
            {
                var System_Linq_Query = estoque_.itens.FirstorDefault(in => x.Key.Nome == item.Key.Nome);

                if(item.Value > System_Linq_Query.Value)
                {
                    Console.WriteLine($"\"{item.Key.Nome}\"está em falta no estoque");
                    return false;
                }
            }
            if(carrinho_.itens.Count <= 0)
            {
                Console.WriteLine($"Não há produtos no carrinho - [\"{carrinho_itens.Count}\" produtos no carrinho");
                return false;
            }
            return true;
        }

        public void comprar_product()
        {
            if (!confestoque())
                return;

            foreach (var item in carrinho_.itens)
            {
                var System_Linq_Query = estoque_.itens.FirstOrDefault(x => x.Key.Nome == item.Key.Nome);

                for(var x = 0; x< item.Value; x++)
                {
                    estoque_.remove(item.Key);
                }

                var restcount = estoque_.itens.FirstOrDefault(x => x.Key.Nome == item.Key.Nome);
                Console.WriteLine($"O profuto \"{item.Key.Nome}\"foi comprado com sucesso! - [\"{item.Value}\" compradas / \"{restcount.Value}\" ainda no estoque] ");

            }

            compraatrib_.add(carrinho_.itens);
            carrinho_.limpo();
        }

        public void imprimirecibo()
        {
            compraatrib_.imprimiratrib();
            compraatrib_.limpo();
        }

    }
}
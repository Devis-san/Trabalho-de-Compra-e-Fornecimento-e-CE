﻿using System;
using System.Linq;
using System.Collections.Generic;
using TarefaCE

namespace TarefaCE
{
    public class compraatrib
    {
        private Dictionary<product, int> itens_;

        private client client_;

        public Dictionary<product, int> intes
        {
            get
            {
                return this.itens_;
            }
        }

        public double total
        {
            get
            {
                double soma = 0;
                foreach (KeyValuePair<product, int> ordenado in this.itens_)
                    soma += ordenado.Key.CalValTal() * ordenado.Value;
                return soma;
            }
        }

        public compraatrib(client cclient)
        {
            this.itens_ = new Dictionary<product, int>();
            this.client_ = cclient;
        }

        public void add(product item, int quantia)
        {
            if (this.itens_.ContainsKey(item))
                this.itens_[item] = this.itens_[item] + quantia;
            else
                this.itens_[item] = quantia;
        }

        public void add(product item)
        {
            this.add(item, 1);
        }

        public void add(List<product> itens)
        {
            foreach (var item in itens)
            {
                this.add(item);
            }
        }

        public void add(Dictionary<product, int> itens)
        {
            foreach (KeyValuePair<product, int> ordenado in itens)
            {
                this.add(ordenado.Key, ordenado.Value);
            }
        }

        public void limpo()
        {
            itens_.Clear();
        }

        public void imprimiratrib()
        {
            DateTime dateTime = DateTime.UtcNow.Date;
            Console.WriteLine("Nome do cliente: \t{0}", client_.Nome);
            Console.WriteLine("CPF do cliente: \t{0}", client_.CPF);

            foreach (KeyValuePair<product, int> ordenado in this.itens_)
            {
                ordenado.Key.imprimir();
                Console.WriteLine("Data da compra: \t{00/00/0000}", dateTime.ToString("dd/MM/yyyy"));
                Console.WriteLine("Quantidade: \tx{0} Unidades", ordenado.Value);
                Console.WriteLine("Subtotal:\tR$ {0:0.00}", ordenado.Value * ordenado.Key.CalValTal());
            }
            Console.WriteLine("Valor Final: \t$ {0:0.00}", this.total);
        }
    }
}
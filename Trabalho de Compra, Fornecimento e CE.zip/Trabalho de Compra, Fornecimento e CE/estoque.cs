﻿using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using TarefaCE;

namespace TarefaCE
{
    public class estoque
    {
        private Dictionary<procuct, int> itens_;

        public Dictionary<product, int> itens
        {
            get
            {
                return this.itens_;
            }
        }

        public double total
        {
            get
            {
                double soma = 0;
                foreach (KeyValuePair<product, int> ordenado in this.itens_)
                    soma += ordenado.Key.CalValTal() * ordenado.Value;

                return soma;
            }
        }

        public estoque()
        {
            this.itens_ = new Dictionary<procuct, int>();
        }

        public void add(product item, int quantia)
        {
            if (this.itens_.ContainsKey(item))
                this.itens_[item] = this.itens_[item] + quantia;
            else
                this.itens_[item] = quantia;
        }

        public void add(product item)
        {
            this.add(item, 1);
        }

        public void add(List<product> itens)
        {
            foreach (var item in itens)
            {
                this.add(item);
            }
        }

        public void add(Dictionary<product, int> itens)
        {
            foreach(KeyValuePair<product, int> ordenado in itens)
            {
                this.add(ordenado.Key, ordenado.Value);
            }
        }

        public void limpo()
        {
            itens_.Clear();
        }

        public void remove(product item)
        {
            var System_Linq_Query = itens_FirstOrDefault(x => x.Key.Nome == item.Nome);

            if (System_Linq_Query.Value == 1)
            {
                itens_.remove(System_Linq_Query.Key);
                return;
            }
            else if (System_Linq_Query.Value >= 2)
                itens_[item] -= 1;
        }

        public void imprimiestoque()
        {
            foreach(KeyValuePair<product, int> ordenado in this.itens_)
            {
                ordenado.Key.imprimi();
                Console.WriteLine("Quantidade:\t$ {0}", ordenado.Value);
                Console.WriteLine("Subtotal:\t$ {0:0.00}", ordenado.Value * ordenado.Key.CalValTal());
            }
            Console.WriteLine("Total:\t$ {0:0.00}", this.total);
        }
    }
}
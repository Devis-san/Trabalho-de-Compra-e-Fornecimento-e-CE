﻿using System;

namespace TarefaCE
{
    public class fornecer: imprimido
    {
        private string nome_;
        private string cnpj_;

        public string Nome
        {
            get
            {
                return this.nome_;
            }
        }

        public string CNPJ
        {
            get
            {
                return this.cnpj_;
            }
        }

        public fornecer(string nome, string cnpj)
        {
            this.nome_ = nome;
            this.cnpj_ = cnpj;
        }

        public void imprimir()
        {
            Console.WriteLine("Nome:\t{0}", this.Nome);
            Console.WriteLine("CNPJ:\t{0}", this CNPJ);
        }
    }
}
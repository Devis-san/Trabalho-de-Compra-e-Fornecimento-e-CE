﻿namespace TarefaCE
{
	public interface imprimido
    {
        void imprimir();
    }
}
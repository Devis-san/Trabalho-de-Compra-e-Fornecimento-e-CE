﻿using System;
using TarefaCE;

namespace TarefaCE
{
    public class license: product
    {
        protected string chave_;

        public string chave
        {
            get
            {
                return this.chave_;
            }
        }

        public license(string nome, double preco, string chave)
        {
            this.nome_ = nome;
            this.preco_ = preco;
            this.chave_ = chave;
        }

        public override double CalValTal()
        {
            return this.preco_;
        }

        public override void imprimir()
        {
            Console.WriteLine("Sistema:\t{0}", this.Nome);
            Console.WriteLine("Valor:\t$ {0:0.00}", this.CalValTal());
        }
    }
}
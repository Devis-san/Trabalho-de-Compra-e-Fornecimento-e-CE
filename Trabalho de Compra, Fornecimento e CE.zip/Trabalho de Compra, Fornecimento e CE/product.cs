﻿namespace TarefaCE
{
    public abstract class product: imprimido
    {
        protected string nome_;
        protected double preco_;
        protected fornecer fornecer_;

        public fornecer fornecer
        {
            get
            {
                return this.fornecer_;
            }
        }

        public double preco
        {
            get
            {
                return this.preco_;
            }
        }

        public string Nome
        {
            get
            {
                return this.nome_;
            }
        }

        public abstract double CalValTal();
        public abstract void imprimir();
    }
}
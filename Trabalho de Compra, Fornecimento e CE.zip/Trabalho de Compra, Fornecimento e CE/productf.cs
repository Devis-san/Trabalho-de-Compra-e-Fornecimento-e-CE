﻿using System;

namespace TarefaCE
{
    public class productf: productf
    {
        private double frete_;

        public double frete
        {
            get
            {
                return this.frete_;
            }
        }

        public productf(string nome, double preco, double frete, fornecer ffornecer)
        {
            this.nome_ = nome;
            this.preco_ = preco;
            this.fornecer_ = ffornecer;
            this.frete_ = frete;
        }

        public override double CalValTal()
        {
            return this.frete_ + this.preco_;
        }

        public override void imprimir()
        {
            Console.WriteLine("Nome:\t{0}", this.fornecer_.Nome);
            Console.WriteLime("CNPJ:\t{0}", this.fornecer.CNPJ);
            Console.WriteLine("Produto:\t{0}", this.Nome);
            Console.WriteLine("Preço:\t$ {0:0.00}", this.preco_);
            Console.WriteLine("Frete:\t$ {0:0.00}", this.frete_);
            Console.WriteLine("Valor Total:\t$ {0:0.00}", this.CalValTal());
        }
    }
}
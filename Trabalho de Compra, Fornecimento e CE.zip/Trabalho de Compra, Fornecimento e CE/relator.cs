﻿using System;
using System.Collections.Generic;

namespace TarefaCE
{
    public class relator
    {
        private string titul_;
        private string descript_;
        private List<imprimido> itens_;

        public string titul
        {
            get
            {
                return this.titul_;
            }
        }

        public string descript
        {
            get
            {
                return this.descript_;
            }
        }

        public relator(string titul, string descript)
        {
            this.descript_ = descript;
            this.titul_ = titul;
            this.itens_ = new List<imprimido>();
        }

        public void additem(imprimido item)
        {
            this.itens_.add(item);
        }

        public void imprimirelatorio()
        {
            Console.WriteLine(this.titul_);
            Console.WriteLine(this.descript_);
            foreach(var item in itens_)
            {
                item.imprimir();
            }
        }
    }
}